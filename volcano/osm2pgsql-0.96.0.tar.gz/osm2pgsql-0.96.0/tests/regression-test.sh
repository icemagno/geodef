#!/usr/bin/env sh

tests/regression-test.py -f tests/liechtenstein-2013-08-03.osm.pbf
echo "Tests passed :-)"
