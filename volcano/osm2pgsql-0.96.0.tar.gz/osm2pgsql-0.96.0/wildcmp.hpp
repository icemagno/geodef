#ifndef WILDCMP_H
#define WILDCMP_H

bool wildMatch(const char* wildCard, const char* string);

#endif
