# Gazetteer Backend #

The gazetteer backend is designed for use with
[Nominatim](http://wiki.openstreetmap.org/wiki/Nominatim)
and will not generally be used outside that context.

The tables are designed for a hiarchy of places.
