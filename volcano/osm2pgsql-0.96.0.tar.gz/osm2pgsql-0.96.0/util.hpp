#ifndef UTIL_H
#define UTIL_H

namespace util {

	void exit_nicely();
}


#endif
