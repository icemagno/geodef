--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.8 (Debian 11.8-1.pgdg90+1)
-- Dumped by pg_dump version 11.8 (Debian 11.8-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE atlas;
--
-- Name: atlas; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE atlas WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE atlas OWNER TO postgres;

\connect atlas

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_log (
    log_id bigint NOT NULL,
    access_type character varying(255),
    date timestamp without time zone,
    header text,
    method character varying(20),
    profileimage character varying(100),
    querystring character varying(255),
    remoteaddr character varying(50),
    remotehost character varying(50),
    remoteuser character varying(100),
    remoteuserid bigint,
    remoteusername character varying(255),
    requesturl character varying(255)
);


ALTER TABLE public.access_log OWNER TO postgres;

--
-- Name: access_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_log_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.access_log_log_id_seq OWNER TO postgres;

--
-- Name: access_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_log_log_id_seq OWNED BY public.access_log.log_id;


--
-- Name: catalog_source; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_source (
    source_id bigint NOT NULL,
    description text,
    source_address character varying(250) NOT NULL,
    source_name character varying(100) NOT NULL,
    topic_id integer,
    parent_id integer,
    source_layer character varying(100),
    bbox character varying(100),
    cql_filter character varying(250)
);


ALTER TABLE public.catalog_source OWNER TO postgres;

--
-- Name: catalog_source_source_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_source_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_source_source_id_seq OWNER TO postgres;

--
-- Name: catalog_source_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_source_source_id_seq OWNED BY public.catalog_source.source_id;


--
-- Name: catalog_topics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_topics (
    topic_id bigint NOT NULL,
    description text,
    topic_name character varying(100) NOT NULL
);


ALTER TABLE public.catalog_topics OWNER TO postgres;

--
-- Name: catalog_topics_topic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_topics_topic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_topics_topic_id_seq OWNER TO postgres;

--
-- Name: catalog_topics_topic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_topics_topic_id_seq OWNED BY public.catalog_topics.topic_id;


--
-- Name: clientdetails; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clientdetails (
    client_id character varying(255) NOT NULL,
    access_token_validity integer,
    additional_information text,
    app_id character varying(255),
    app_secret character varying(255),
    authorities character varying(255),
    auto_approve_scopes character varying(255),
    grant_types character varying(255),
    redirect_url character varying(255),
    refresh_token_validity integer,
    resource_ids character varying(255),
    scope character varying(255)
);


ALTER TABLE public.clientdetails OWNER TO postgres;

--
-- Name: oauth_access_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_access_token (
    authentication_id character varying(255) NOT NULL,
    authentication bytea,
    client_id character varying(255),
    refresh_token character varying(255),
    token bytea,
    token_id character varying(255),
    user_name character varying(255)
);


ALTER TABLE public.oauth_access_token OWNER TO postgres;

--
-- Name: oauth_approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_approvals (
    pk_id bigint NOT NULL,
    client_id character varying(255),
    expires_at date,
    last_modified_at date,
    scope character varying(255),
    status character varying(10),
    user_id character varying(255)
);


ALTER TABLE public.oauth_approvals OWNER TO postgres;

--
-- Name: oauth_approvals_pk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_approvals_pk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_approvals_pk_id_seq OWNER TO postgres;

--
-- Name: oauth_approvals_pk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_approvals_pk_id_seq OWNED BY public.oauth_approvals.pk_id;


--
-- Name: oauth_client_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_client_details (
    client_id character varying(255) NOT NULL,
    access_token_validity integer,
    additional_information text,
    authorities character varying(255),
    authorized_grant_types character varying(255),
    autoapprove character varying(50),
    client_secret character varying(255),
    refresh_token_validity integer,
    resource_ids character varying(255),
    scope character varying(255),
    web_server_redirect_uri character varying(255)
);


ALTER TABLE public.oauth_client_details OWNER TO postgres;

--
-- Name: oauth_client_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_client_token (
    authentication_id character varying(255) NOT NULL,
    client_id character varying(255),
    token bytea,
    token_id character varying(255),
    user_name character varying(255)
);


ALTER TABLE public.oauth_client_token OWNER TO postgres;

--
-- Name: oauth_code; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_code (
    pk_id bigint NOT NULL,
    authentication bytea,
    code character varying(255)
);


ALTER TABLE public.oauth_code OWNER TO postgres;

--
-- Name: oauth_code_pk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_code_pk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_code_pk_id_seq OWNER TO postgres;

--
-- Name: oauth_code_pk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_code_pk_id_seq OWNED BY public.oauth_code.pk_id;


--
-- Name: oauth_refresh_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_refresh_token (
    pk_id bigint NOT NULL,
    authentication bytea,
    token bytea,
    token_id character varying(255)
);


ALTER TABLE public.oauth_refresh_token OWNER TO postgres;

--
-- Name: oauth_refresh_token_pk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_refresh_token_pk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_refresh_token_pk_id_seq OWNER TO postgres;

--
-- Name: oauth_refresh_token_pk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_refresh_token_pk_id_seq OWNED BY public.oauth_refresh_token.pk_id;


--
-- Name: passwords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passwords (
    password_id bigint NOT NULL,
    password character varying(100) NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.passwords OWNER TO postgres;

--
-- Name: passwords_password_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.passwords_password_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.passwords_password_id_seq OWNER TO postgres;

--
-- Name: passwords_password_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.passwords_password_id_seq OWNED BY public.passwords.password_id;


--
-- Name: temp_marinha; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.temp_marinha (
    id_node integer,
    layer_name character varying(100),
    nome character varying(100),
    geoserver_url character varying(100),
    pasta_superior character varying(100),
    pasta_sup_2 character varying(100),
    pasta_sup_3 character varying(100),
    pasta_sup_4 character varying(100)
);


ALTER TABLE public.temp_marinha OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id bigint NOT NULL,
    cpf character varying(14),
    email character varying(100),
    enabled boolean NOT NULL,
    full_name character varying(200) NOT NULL,
    funcao character varying(100),
    user_name character varying(100) NOT NULL,
    origem character varying(200),
    password character varying(100) NOT NULL,
    profile_image character varying(255) NOT NULL,
    setor character varying(100),
    telefone character varying(20),
    temp_password character varying(100),
    mustchange boolean
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_clients (
    dt_alteracao timestamp without time zone,
    dt_final timestamp without time zone,
    dt_inicial timestamp without time zone,
    respalteracao character varying(255),
    sysadmin boolean,
    tipoalteracao character varying(255),
    client_client_id character varying(255) NOT NULL,
    user_user_id bigint NOT NULL
);


ALTER TABLE public.users_clients OWNER TO postgres;

--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_roles (
    user_role_id bigint NOT NULL,
    role_name character varying(255) NOT NULL,
    user_id bigint
);


ALTER TABLE public.users_roles OWNER TO postgres;

--
-- Name: users_roles_user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_roles_user_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_roles_user_role_id_seq OWNER TO postgres;

--
-- Name: users_roles_user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_roles_user_role_id_seq OWNED BY public.users_roles.user_role_id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: access_log log_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log ALTER COLUMN log_id SET DEFAULT nextval('public.access_log_log_id_seq'::regclass);


--
-- Name: catalog_source source_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_source ALTER COLUMN source_id SET DEFAULT nextval('public.catalog_source_source_id_seq'::regclass);


--
-- Name: catalog_topics topic_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_topics ALTER COLUMN topic_id SET DEFAULT nextval('public.catalog_topics_topic_id_seq'::regclass);


--
-- Name: oauth_approvals pk_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_approvals ALTER COLUMN pk_id SET DEFAULT nextval('public.oauth_approvals_pk_id_seq'::regclass);


--
-- Name: oauth_code pk_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_code ALTER COLUMN pk_id SET DEFAULT nextval('public.oauth_code_pk_id_seq'::regclass);


--
-- Name: oauth_refresh_token pk_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_token ALTER COLUMN pk_id SET DEFAULT nextval('public.oauth_refresh_token_pk_id_seq'::regclass);


--
-- Name: passwords password_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwords ALTER COLUMN password_id SET DEFAULT nextval('public.passwords_password_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_roles user_role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_roles ALTER COLUMN user_role_id SET DEFAULT nextval('public.users_roles_user_role_id_seq'::regclass);


--
-- Data for Name: access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_log (log_id, access_type, date, header, method, profileimage, querystring, remoteaddr, remotehost, remoteuser, remoteuserid, remoteusername, requesturl) FROM stdin;
\.
COPY public.access_log (log_id, access_type, date, header, method, profileimage, querystring, remoteaddr, remotehost, remoteuser, remoteuserid, remoteusername, requesturl) FROM '$$PATH$$/2994.dat';

--
-- Data for Name: catalog_source; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.catalog_source (source_id, description, source_address, source_name, topic_id, parent_id, source_layer, bbox, cql_filter) FROM stdin;
\.
COPY public.catalog_source (source_id, description, source_address, source_name, topic_id, parent_id, source_layer, bbox, cql_filter) FROM '$$PATH$$/3012.dat';

--
-- Data for Name: catalog_topics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.catalog_topics (topic_id, description, topic_name) FROM stdin;
\.
COPY public.catalog_topics (topic_id, description, topic_name) FROM '$$PATH$$/3014.dat';

--
-- Data for Name: clientdetails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clientdetails (client_id, access_token_validity, additional_information, app_id, app_secret, authorities, auto_approve_scopes, grant_types, redirect_url, refresh_token_validity, resource_ids, scope) FROM stdin;
\.
COPY public.clientdetails (client_id, access_token_validity, additional_information, app_id, app_secret, authorities, auto_approve_scopes, grant_types, redirect_url, refresh_token_validity, resource_ids, scope) FROM '$$PATH$$/2992.dat';

--
-- Data for Name: oauth_access_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_access_token (authentication_id, authentication, client_id, refresh_token, token, token_id, user_name) FROM stdin;
\.
COPY public.oauth_access_token (authentication_id, authentication, client_id, refresh_token, token, token_id, user_name) FROM '$$PATH$$/2995.dat';

--
-- Data for Name: oauth_approvals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_approvals (pk_id, client_id, expires_at, last_modified_at, scope, status, user_id) FROM stdin;
\.
COPY public.oauth_approvals (pk_id, client_id, expires_at, last_modified_at, scope, status, user_id) FROM '$$PATH$$/2997.dat';

--
-- Data for Name: oauth_client_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_client_details (client_id, access_token_validity, additional_information, authorities, authorized_grant_types, autoapprove, client_secret, refresh_token_validity, resource_ids, scope, web_server_redirect_uri) FROM stdin;
\.
COPY public.oauth_client_details (client_id, access_token_validity, additional_information, authorities, authorized_grant_types, autoapprove, client_secret, refresh_token_validity, resource_ids, scope, web_server_redirect_uri) FROM '$$PATH$$/2998.dat';

--
-- Data for Name: oauth_client_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_client_token (authentication_id, client_id, token, token_id, user_name) FROM stdin;
\.
COPY public.oauth_client_token (authentication_id, client_id, token, token_id, user_name) FROM '$$PATH$$/2999.dat';

--
-- Data for Name: oauth_code; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_code (pk_id, authentication, code) FROM stdin;
\.
COPY public.oauth_code (pk_id, authentication, code) FROM '$$PATH$$/3001.dat';

--
-- Data for Name: oauth_refresh_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_refresh_token (pk_id, authentication, token, token_id) FROM stdin;
\.
COPY public.oauth_refresh_token (pk_id, authentication, token, token_id) FROM '$$PATH$$/3003.dat';

--
-- Data for Name: passwords; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passwords (password_id, password, user_id) FROM stdin;
\.
COPY public.passwords (password_id, password, user_id) FROM '$$PATH$$/3005.dat';

--
-- Data for Name: temp_marinha; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temp_marinha (id_node, layer_name, nome, geoserver_url, pasta_superior, pasta_sup_2, pasta_sup_3, pasta_sup_4) FROM stdin;
\.
COPY public.temp_marinha (id_node, layer_name, nome, geoserver_url, pasta_superior, pasta_sup_2, pasta_sup_3, pasta_sup_4) FROM '$$PATH$$/3015.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, cpf, email, enabled, full_name, funcao, user_name, origem, password, profile_image, setor, telefone, temp_password, mustchange) FROM stdin;
\.
COPY public.users (user_id, cpf, email, enabled, full_name, funcao, user_name, origem, password, profile_image, setor, telefone, temp_password, mustchange) FROM '$$PATH$$/3007.dat';

--
-- Data for Name: users_clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_clients (dt_alteracao, dt_final, dt_inicial, respalteracao, sysadmin, tipoalteracao, client_client_id, user_user_id) FROM stdin;
\.
COPY public.users_clients (dt_alteracao, dt_final, dt_inicial, respalteracao, sysadmin, tipoalteracao, client_client_id, user_user_id) FROM '$$PATH$$/3008.dat';

--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_roles (user_role_id, role_name, user_id) FROM stdin;
\.
COPY public.users_roles (user_role_id, role_name, user_id) FROM '$$PATH$$/3010.dat';

--
-- Name: access_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_log_log_id_seq', 251, true);


--
-- Name: catalog_source_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_source_source_id_seq', 2124, true);


--
-- Name: catalog_topics_topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_topics_topic_id_seq', 7, true);


--
-- Name: oauth_approvals_pk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_approvals_pk_id_seq', 1, false);


--
-- Name: oauth_code_pk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_code_pk_id_seq', 1, false);


--
-- Name: oauth_refresh_token_pk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_refresh_token_pk_id_seq', 115, true);


--
-- Name: passwords_password_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.passwords_password_id_seq', 10, true);


--
-- Name: users_roles_user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_roles_user_role_id_seq', 501, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 597, true);


--
-- Name: access_log access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log
    ADD CONSTRAINT access_log_pkey PRIMARY KEY (log_id);


--
-- Name: catalog_source catalog_source_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_source
    ADD CONSTRAINT catalog_source_pkey PRIMARY KEY (source_id);


--
-- Name: catalog_topics catalog_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_topics
    ADD CONSTRAINT catalog_topics_pkey PRIMARY KEY (topic_id);


--
-- Name: clientdetails clientdetails_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientdetails
    ADD CONSTRAINT clientdetails_pkey PRIMARY KEY (client_id);


--
-- Name: oauth_access_token oauth_access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_pkey PRIMARY KEY (authentication_id);


--
-- Name: oauth_approvals oauth_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_approvals
    ADD CONSTRAINT oauth_approvals_pkey PRIMARY KEY (pk_id);


--
-- Name: oauth_client_details oauth_client_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_client_details
    ADD CONSTRAINT oauth_client_details_pkey PRIMARY KEY (client_id);


--
-- Name: oauth_client_token oauth_client_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_client_token
    ADD CONSTRAINT oauth_client_token_pkey PRIMARY KEY (authentication_id);


--
-- Name: oauth_code oauth_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_code
    ADD CONSTRAINT oauth_code_pkey PRIMARY KEY (pk_id);


--
-- Name: oauth_refresh_token oauth_refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_pkey PRIMARY KEY (pk_id);


--
-- Name: passwords passwords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwords
    ADD CONSTRAINT passwords_pkey PRIMARY KEY (password_id);


--
-- Name: catalog_topics uk_3croosanib75lia0io9f51h96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_topics
    ADD CONSTRAINT uk_3croosanib75lia0io9f51h96 UNIQUE (topic_name);


--
-- Name: users uk_k8d0f2n7n88w1a16yhua64onx; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_k8d0f2n7n88w1a16yhua64onx UNIQUE (user_name);


--
-- Name: users_clients users_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_clients
    ADD CONSTRAINT users_clients_pkey PRIMARY KEY (client_client_id, user_user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users_roles users_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_roles
    ADD CONSTRAINT users_roles_pkey PRIMARY KEY (user_role_id);


--
-- Name: users_clients fk24srl1mfr8r3qvdqj94d9k9d5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_clients
    ADD CONSTRAINT fk24srl1mfr8r3qvdqj94d9k9d5 FOREIGN KEY (user_user_id) REFERENCES public.users(user_id);


--
-- Name: catalog_source fk343sqat7f0fn9axdpyjw7q1mt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_source
    ADD CONSTRAINT fk343sqat7f0fn9axdpyjw7q1mt FOREIGN KEY (parent_id) REFERENCES public.catalog_source(source_id);


--
-- Name: users_roles fk_datalayer_server; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_roles
    ADD CONSTRAINT fk_datalayer_server FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: users_clients fkkvrf67oq0dsiwmt3uylmh3efy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_clients
    ADD CONSTRAINT fkkvrf67oq0dsiwmt3uylmh3efy FOREIGN KEY (client_client_id) REFERENCES public.oauth_client_details(client_id);


--
-- Name: catalog_source fkqp49wbw30a0rc1al8lbax7pll; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_source
    ADD CONSTRAINT fkqp49wbw30a0rc1al8lbax7pll FOREIGN KEY (topic_id) REFERENCES public.catalog_topics(topic_id);


--
-- PostgreSQL database dump complete
--

