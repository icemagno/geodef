--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.8 (Debian 11.8-1.pgdg100+1)
-- Dumped by pg_dump version 11.8 (Debian 11.8-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE atlas;
--
-- Name: atlas; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE atlas WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE atlas OWNER TO postgres;

\connect atlas

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: atlas; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE atlas SET search_path TO '$user', 'public', 'topology';


\connect atlas

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_cron; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA public;


--
-- Name: EXTENSION pg_cron; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_cron IS 'Job scheduler for PostgreSQL';


--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: asbinary(public.geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.asbinary(public.geometry) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-2.5', 'LWGEOM_asBinary';


ALTER FUNCTION public.asbinary(public.geometry) OWNER TO postgres;

--
-- Name: asbinary(public.geometry, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.asbinary(public.geometry, text) RETURNS bytea
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-2.5', 'LWGEOM_asBinary';


ALTER FUNCTION public.asbinary(public.geometry, text) OWNER TO postgres;

--
-- Name: astext(public.geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.astext(public.geometry) RETURNS text
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-2.5', 'LWGEOM_asText';


ALTER FUNCTION public.astext(public.geometry) OWNER TO postgres;

--
-- Name: estimated_extent(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.estimated_extent(text, text) RETURNS public.box2d
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER
    AS '$libdir/postgis-2.5', 'geometry_estimated_extent';


ALTER FUNCTION public.estimated_extent(text, text) OWNER TO postgres;

--
-- Name: estimated_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.estimated_extent(text, text, text) RETURNS public.box2d
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER
    AS '$libdir/postgis-2.5', 'geometry_estimated_extent';


ALTER FUNCTION public.estimated_extent(text, text, text) OWNER TO postgres;

--
-- Name: geomfromtext(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.geomfromtext(text) RETURNS public.geometry
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$SELECT ST_GeomFromText($1)$_$;


ALTER FUNCTION public.geomfromtext(text) OWNER TO postgres;

--
-- Name: geomfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.geomfromtext(text, integer) RETURNS public.geometry
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$SELECT ST_GeomFromText($1, $2)$_$;


ALTER FUNCTION public.geomfromtext(text, integer) OWNER TO postgres;

--
-- Name: ndims(public.geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ndims(public.geometry) RETURNS smallint
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-2.5', 'LWGEOM_ndims';


ALTER FUNCTION public.ndims(public.geometry) OWNER TO postgres;

--
-- Name: setsrid(public.geometry, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.setsrid(public.geometry, integer) RETURNS public.geometry
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-2.5', 'LWGEOM_set_srid';


ALTER FUNCTION public.setsrid(public.geometry, integer) OWNER TO postgres;

--
-- Name: srid(public.geometry); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.srid(public.geometry) RETURNS integer
    LANGUAGE c IMMUTABLE STRICT
    AS '$libdir/postgis-2.5', 'LWGEOM_get_srid';


ALTER FUNCTION public.srid(public.geometry) OWNER TO postgres;

--
-- Name: st_asbinary(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.st_asbinary(text) RETURNS bytea
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT ST_AsBinary($1::geometry);$_$;


ALTER FUNCTION public.st_asbinary(text) OWNER TO postgres;

--
-- Name: st_astext(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.st_astext(bytea) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$ SELECT ST_AsText($1::geometry);$_$;


ALTER FUNCTION public.st_astext(bytea) OWNER TO postgres;

--
-- Name: gist_geometry_ops; Type: OPERATOR FAMILY; Schema: public; Owner: postgres
--

CREATE OPERATOR FAMILY public.gist_geometry_ops USING gist;


ALTER OPERATOR FAMILY public.gist_geometry_ops USING gist OWNER TO postgres;

--
-- Name: gist_geometry_ops; Type: OPERATOR CLASS; Schema: public; Owner: postgres
--

CREATE OPERATOR CLASS public.gist_geometry_ops
    FOR TYPE public.geometry USING gist FAMILY public.gist_geometry_ops AS
    STORAGE public.box2df ,
    OPERATOR 1 public.<<(public.geometry,public.geometry) ,
    OPERATOR 2 public.&<(public.geometry,public.geometry) ,
    OPERATOR 3 public.&&(public.geometry,public.geometry) ,
    OPERATOR 4 public.&>(public.geometry,public.geometry) ,
    OPERATOR 5 public.>>(public.geometry,public.geometry) ,
    OPERATOR 6 public.~=(public.geometry,public.geometry) ,
    OPERATOR 7 public.~(public.geometry,public.geometry) ,
    OPERATOR 8 public.@(public.geometry,public.geometry) ,
    OPERATOR 9 public.&<|(public.geometry,public.geometry) ,
    OPERATOR 10 public.<<|(public.geometry,public.geometry) ,
    OPERATOR 11 public.|>>(public.geometry,public.geometry) ,
    OPERATOR 12 public.|&>(public.geometry,public.geometry) ,
    OPERATOR 13 public.<->(public.geometry,public.geometry) FOR ORDER BY pg_catalog.float_ops ,
    OPERATOR 14 public.<#>(public.geometry,public.geometry) FOR ORDER BY pg_catalog.float_ops ,
    FUNCTION 1 (public.geometry, public.geometry) public.geometry_gist_consistent_2d(internal,public.geometry,integer) ,
    FUNCTION 2 (public.geometry, public.geometry) public.geometry_gist_union_2d(bytea,internal) ,
    FUNCTION 3 (public.geometry, public.geometry) public.geometry_gist_compress_2d(internal) ,
    FUNCTION 4 (public.geometry, public.geometry) public.geometry_gist_decompress_2d(internal) ,
    FUNCTION 5 (public.geometry, public.geometry) public.geometry_gist_penalty_2d(internal,internal,internal) ,
    FUNCTION 6 (public.geometry, public.geometry) public.geometry_gist_picksplit_2d(internal,internal) ,
    FUNCTION 7 (public.geometry, public.geometry) public.geometry_gist_same_2d(public.geometry,public.geometry,internal) ,
    FUNCTION 8 (public.geometry, public.geometry) public.geometry_gist_distance_2d(internal,public.geometry,integer);


ALTER OPERATOR CLASS public.gist_geometry_ops USING gist OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: access_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_log (
    log_id bigint NOT NULL,
    access_type character varying(255),
    date timestamp without time zone,
    header text,
    method character varying(20),
    profileimage character varying(100),
    querystring character varying(255),
    remoteaddr character varying(50),
    remotehost character varying(50),
    remoteuser character varying(100),
    remoteuserid bigint,
    remoteusername character varying(255),
    requesturl character varying(255)
);


ALTER TABLE public.access_log OWNER TO postgres;

--
-- Name: access_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_log_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.access_log_log_id_seq OWNER TO postgres;

--
-- Name: access_log_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_log_log_id_seq OWNED BY public.access_log.log_id;


--
-- Name: catalog_source; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_source (
    source_id bigint NOT NULL,
    description text,
    source_address character varying(250) NOT NULL,
    source_name character varying(100) NOT NULL,
    topic_id integer,
    parent_id integer,
    source_layer character varying(100),
    bbox character varying(100),
    cql_filter character varying(250),
    source_logo character varying(250),
    geonetwork_id character varying(250),
    source_address_original character varying(250)
);


ALTER TABLE public.catalog_source OWNER TO postgres;

--
-- Name: catalog_source_source_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_source_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_source_source_id_seq OWNER TO postgres;

--
-- Name: catalog_source_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_source_source_id_seq OWNED BY public.catalog_source.source_id;


--
-- Name: catalog_topics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog_topics (
    topic_id bigint NOT NULL,
    description text,
    topic_name character varying(100) NOT NULL,
    ordem integer
);


ALTER TABLE public.catalog_topics OWNER TO postgres;

--
-- Name: catalog_topics_topic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.catalog_topics_topic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.catalog_topics_topic_id_seq OWNER TO postgres;

--
-- Name: catalog_topics_topic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.catalog_topics_topic_id_seq OWNED BY public.catalog_topics.topic_id;


--
-- Name: clientdetails; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clientdetails (
    client_id character varying(255) NOT NULL,
    access_token_validity integer,
    additional_information text,
    app_id character varying(255),
    app_secret character varying(255),
    authorities character varying(255),
    auto_approve_scopes character varying(255),
    grant_types character varying(255),
    redirect_url character varying(255),
    refresh_token_validity integer,
    resource_ids character varying(255),
    scope character varying(255)
);


ALTER TABLE public.clientdetails OWNER TO postgres;

--
-- Name: oauth_access_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_access_token (
    authentication_id character varying(255) NOT NULL,
    authentication bytea,
    client_id character varying(255),
    refresh_token character varying(255),
    token bytea,
    token_id character varying(255),
    user_name character varying(255)
);


ALTER TABLE public.oauth_access_token OWNER TO postgres;

--
-- Name: oauth_approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_approvals (
    pk_id bigint NOT NULL,
    client_id character varying(255),
    expires_at date,
    last_modified_at date,
    scope character varying(255),
    status character varying(10),
    user_id character varying(255)
);


ALTER TABLE public.oauth_approvals OWNER TO postgres;

--
-- Name: oauth_approvals_pk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_approvals_pk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_approvals_pk_id_seq OWNER TO postgres;

--
-- Name: oauth_approvals_pk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_approvals_pk_id_seq OWNED BY public.oauth_approvals.pk_id;


--
-- Name: oauth_client_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_client_details (
    client_id character varying(255) NOT NULL,
    access_token_validity integer,
    additional_information text,
    authorities character varying(255),
    authorized_grant_types character varying(255),
    autoapprove character varying(50),
    client_secret character varying(255),
    refresh_token_validity integer,
    resource_ids character varying(255),
    scope character varying(255),
    web_server_redirect_uri character varying(255)
);


ALTER TABLE public.oauth_client_details OWNER TO postgres;

--
-- Name: oauth_client_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_client_token (
    authentication_id character varying(255) NOT NULL,
    client_id character varying(255),
    token bytea,
    token_id character varying(255),
    user_name character varying(255)
);


ALTER TABLE public.oauth_client_token OWNER TO postgres;

--
-- Name: oauth_code; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_code (
    pk_id bigint NOT NULL,
    authentication bytea,
    code character varying(255)
);


ALTER TABLE public.oauth_code OWNER TO postgres;

--
-- Name: oauth_code_pk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_code_pk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_code_pk_id_seq OWNER TO postgres;

--
-- Name: oauth_code_pk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_code_pk_id_seq OWNED BY public.oauth_code.pk_id;


--
-- Name: oauth_refresh_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_refresh_token (
    pk_id bigint NOT NULL,
    authentication bytea,
    token bytea,
    token_id character varying(255)
);


ALTER TABLE public.oauth_refresh_token OWNER TO postgres;

--
-- Name: oauth_refresh_token_pk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.oauth_refresh_token_pk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oauth_refresh_token_pk_id_seq OWNER TO postgres;

--
-- Name: oauth_refresh_token_pk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.oauth_refresh_token_pk_id_seq OWNED BY public.oauth_refresh_token.pk_id;


--
-- Name: passwords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passwords (
    password_id bigint NOT NULL,
    password character varying(100) NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.passwords OWNER TO postgres;

--
-- Name: passwords_password_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.passwords_password_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.passwords_password_id_seq OWNER TO postgres;

--
-- Name: passwords_password_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.passwords_password_id_seq OWNED BY public.passwords.password_id;


--
-- Name: temp_marinha; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.temp_marinha (
    id_node integer,
    layer_name character varying(100),
    nome character varying(100),
    geoserver_url character varying(100),
    pasta_superior character varying(100),
    pasta_sup_2 character varying(100),
    pasta_sup_3 character varying(100),
    pasta_sup_4 character varying(100)
);


ALTER TABLE public.temp_marinha OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id bigint NOT NULL,
    cpf character varying(14),
    email character varying(100),
    enabled boolean NOT NULL,
    full_name character varying(200) NOT NULL,
    funcao character varying(100),
    user_name character varying(100) NOT NULL,
    origem character varying(200),
    password character varying(100) NOT NULL,
    profile_image character varying(255) NOT NULL,
    setor character varying(100),
    telefone character varying(20),
    temp_password character varying(100),
    mustchange boolean
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_clients (
    dt_alteracao timestamp without time zone,
    dt_final timestamp without time zone,
    dt_inicial timestamp without time zone,
    respalteracao character varying(255),
    sysadmin boolean,
    tipoalteracao character varying(255),
    client_client_id character varying(255) NOT NULL,
    user_user_id bigint NOT NULL
);


ALTER TABLE public.users_clients OWNER TO postgres;

--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_roles (
    user_role_id bigint NOT NULL,
    role_name character varying(255) NOT NULL,
    user_id bigint
);


ALTER TABLE public.users_roles OWNER TO postgres;

--
-- Name: users_roles_user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_roles_user_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_roles_user_role_id_seq OWNER TO postgres;

--
-- Name: users_roles_user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_roles_user_role_id_seq OWNED BY public.users_roles.user_role_id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: access_log log_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log ALTER COLUMN log_id SET DEFAULT nextval('public.access_log_log_id_seq'::regclass);


--
-- Name: catalog_source source_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_source ALTER COLUMN source_id SET DEFAULT nextval('public.catalog_source_source_id_seq'::regclass);


--
-- Name: catalog_topics topic_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_topics ALTER COLUMN topic_id SET DEFAULT nextval('public.catalog_topics_topic_id_seq'::regclass);


--
-- Name: oauth_approvals pk_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_approvals ALTER COLUMN pk_id SET DEFAULT nextval('public.oauth_approvals_pk_id_seq'::regclass);


--
-- Name: oauth_code pk_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_code ALTER COLUMN pk_id SET DEFAULT nextval('public.oauth_code_pk_id_seq'::regclass);


--
-- Name: oauth_refresh_token pk_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_token ALTER COLUMN pk_id SET DEFAULT nextval('public.oauth_refresh_token_pk_id_seq'::regclass);


--
-- Name: passwords password_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwords ALTER COLUMN password_id SET DEFAULT nextval('public.passwords_password_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_roles user_role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_roles ALTER COLUMN user_role_id SET DEFAULT nextval('public.users_roles_user_role_id_seq'::regclass);


--
-- Data for Name: job; Type: TABLE DATA; Schema: cron; Owner: postgres
--

COPY cron.job (jobid, schedule, command, nodename, nodeport, database, username, active) FROM stdin;
\.
COPY cron.job (jobid, schedule, command, nodename, nodeport, database, username, active) FROM '$$PATH$$/5526.dat';

--
-- Data for Name: access_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_log (log_id, access_type, date, header, method, profileimage, querystring, remoteaddr, remotehost, remoteuser, remoteuserid, remoteusername, requesturl) FROM stdin;
\.
COPY public.access_log (log_id, access_type, date, header, method, profileimage, querystring, remoteaddr, remotehost, remoteuser, remoteuserid, remoteusername, requesturl) FROM '$$PATH$$/5729.dat';

--
-- Data for Name: catalog_source; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.catalog_source (source_id, description, source_address, source_name, topic_id, parent_id, source_layer, bbox, cql_filter, source_logo, geonetwork_id, source_address_original) FROM stdin;
\.
COPY public.catalog_source (source_id, description, source_address, source_name, topic_id, parent_id, source_layer, bbox, cql_filter, source_logo, geonetwork_id, source_address_original) FROM '$$PATH$$/5731.dat';

--
-- Data for Name: catalog_topics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.catalog_topics (topic_id, description, topic_name, ordem) FROM stdin;
\.
COPY public.catalog_topics (topic_id, description, topic_name, ordem) FROM '$$PATH$$/5733.dat';

--
-- Data for Name: clientdetails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clientdetails (client_id, access_token_validity, additional_information, app_id, app_secret, authorities, auto_approve_scopes, grant_types, redirect_url, refresh_token_validity, resource_ids, scope) FROM stdin;
\.
COPY public.clientdetails (client_id, access_token_validity, additional_information, app_id, app_secret, authorities, auto_approve_scopes, grant_types, redirect_url, refresh_token_validity, resource_ids, scope) FROM '$$PATH$$/5735.dat';

--
-- Data for Name: oauth_access_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_access_token (authentication_id, authentication, client_id, refresh_token, token, token_id, user_name) FROM stdin;
\.
COPY public.oauth_access_token (authentication_id, authentication, client_id, refresh_token, token, token_id, user_name) FROM '$$PATH$$/5736.dat';

--
-- Data for Name: oauth_approvals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_approvals (pk_id, client_id, expires_at, last_modified_at, scope, status, user_id) FROM stdin;
\.
COPY public.oauth_approvals (pk_id, client_id, expires_at, last_modified_at, scope, status, user_id) FROM '$$PATH$$/5737.dat';

--
-- Data for Name: oauth_client_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_client_details (client_id, access_token_validity, additional_information, authorities, authorized_grant_types, autoapprove, client_secret, refresh_token_validity, resource_ids, scope, web_server_redirect_uri) FROM stdin;
\.
COPY public.oauth_client_details (client_id, access_token_validity, additional_information, authorities, authorized_grant_types, autoapprove, client_secret, refresh_token_validity, resource_ids, scope, web_server_redirect_uri) FROM '$$PATH$$/5739.dat';

--
-- Data for Name: oauth_client_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_client_token (authentication_id, client_id, token, token_id, user_name) FROM stdin;
\.
COPY public.oauth_client_token (authentication_id, client_id, token, token_id, user_name) FROM '$$PATH$$/5740.dat';

--
-- Data for Name: oauth_code; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_code (pk_id, authentication, code) FROM stdin;
\.
COPY public.oauth_code (pk_id, authentication, code) FROM '$$PATH$$/5741.dat';

--
-- Data for Name: oauth_refresh_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_refresh_token (pk_id, authentication, token, token_id) FROM stdin;
\.
COPY public.oauth_refresh_token (pk_id, authentication, token, token_id) FROM '$$PATH$$/5743.dat';

--
-- Data for Name: passwords; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passwords (password_id, password, user_id) FROM stdin;
\.
COPY public.passwords (password_id, password, user_id) FROM '$$PATH$$/5745.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/5528.dat';

--
-- Data for Name: temp_marinha; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temp_marinha (id_node, layer_name, nome, geoserver_url, pasta_superior, pasta_sup_2, pasta_sup_3, pasta_sup_4) FROM stdin;
\.
COPY public.temp_marinha (id_node, layer_name, nome, geoserver_url, pasta_superior, pasta_sup_2, pasta_sup_3, pasta_sup_4) FROM '$$PATH$$/5747.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, cpf, email, enabled, full_name, funcao, user_name, origem, password, profile_image, setor, telefone, temp_password, mustchange) FROM stdin;
\.
COPY public.users (user_id, cpf, email, enabled, full_name, funcao, user_name, origem, password, profile_image, setor, telefone, temp_password, mustchange) FROM '$$PATH$$/5748.dat';

--
-- Data for Name: users_clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_clients (dt_alteracao, dt_final, dt_inicial, respalteracao, sysadmin, tipoalteracao, client_client_id, user_user_id) FROM stdin;
\.
COPY public.users_clients (dt_alteracao, dt_final, dt_inicial, respalteracao, sysadmin, tipoalteracao, client_client_id, user_user_id) FROM '$$PATH$$/5749.dat';

--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_roles (user_role_id, role_name, user_id) FROM stdin;
\.
COPY public.users_roles (user_role_id, role_name, user_id) FROM '$$PATH$$/5750.dat';

--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.
COPY topology.topology (id, name, srid, "precision", hasz) FROM '$$PATH$$/5529.dat';

--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.
COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM '$$PATH$$/5530.dat';

--
-- Name: jobid_seq; Type: SEQUENCE SET; Schema: cron; Owner: postgres
--

SELECT pg_catalog.setval('cron.jobid_seq', 1, false);


--
-- Name: access_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_log_log_id_seq', 254, true);


--
-- Name: catalog_source_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_source_source_id_seq', 3848, true);


--
-- Name: catalog_topics_topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.catalog_topics_topic_id_seq', 7, true);


--
-- Name: oauth_approvals_pk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_approvals_pk_id_seq', 1, false);


--
-- Name: oauth_code_pk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_code_pk_id_seq', 1, false);


--
-- Name: oauth_refresh_token_pk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oauth_refresh_token_pk_id_seq', 115, true);


--
-- Name: passwords_password_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.passwords_password_id_seq', 10, true);


--
-- Name: users_roles_user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_roles_user_role_id_seq', 504, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 599, true);


--
-- Name: access_log access_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_log
    ADD CONSTRAINT access_log_pkey PRIMARY KEY (log_id);


--
-- Name: catalog_source catalog_source_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_source
    ADD CONSTRAINT catalog_source_pkey PRIMARY KEY (source_id);


--
-- Name: catalog_topics catalog_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_topics
    ADD CONSTRAINT catalog_topics_pkey PRIMARY KEY (topic_id);


--
-- Name: clientdetails clientdetails_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientdetails
    ADD CONSTRAINT clientdetails_pkey PRIMARY KEY (client_id);


--
-- Name: oauth_access_token oauth_access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_pkey PRIMARY KEY (authentication_id);


--
-- Name: oauth_approvals oauth_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_approvals
    ADD CONSTRAINT oauth_approvals_pkey PRIMARY KEY (pk_id);


--
-- Name: oauth_client_details oauth_client_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_client_details
    ADD CONSTRAINT oauth_client_details_pkey PRIMARY KEY (client_id);


--
-- Name: oauth_client_token oauth_client_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_client_token
    ADD CONSTRAINT oauth_client_token_pkey PRIMARY KEY (authentication_id);


--
-- Name: oauth_code oauth_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_code
    ADD CONSTRAINT oauth_code_pkey PRIMARY KEY (pk_id);


--
-- Name: oauth_refresh_token oauth_refresh_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_refresh_token
    ADD CONSTRAINT oauth_refresh_token_pkey PRIMARY KEY (pk_id);


--
-- Name: passwords passwords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwords
    ADD CONSTRAINT passwords_pkey PRIMARY KEY (password_id);


--
-- Name: catalog_topics uk_3croosanib75lia0io9f51h96; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_topics
    ADD CONSTRAINT uk_3croosanib75lia0io9f51h96 UNIQUE (topic_name);


--
-- Name: users uk_k8d0f2n7n88w1a16yhua64onx; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_k8d0f2n7n88w1a16yhua64onx UNIQUE (user_name);


--
-- Name: users_clients users_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_clients
    ADD CONSTRAINT users_clients_pkey PRIMARY KEY (client_client_id, user_user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users_roles users_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_roles
    ADD CONSTRAINT users_roles_pkey PRIMARY KEY (user_role_id);


--
-- Name: users_clients fk24srl1mfr8r3qvdqj94d9k9d5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_clients
    ADD CONSTRAINT fk24srl1mfr8r3qvdqj94d9k9d5 FOREIGN KEY (user_user_id) REFERENCES public.users(user_id);


--
-- Name: catalog_source fk343sqat7f0fn9axdpyjw7q1mt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_source
    ADD CONSTRAINT fk343sqat7f0fn9axdpyjw7q1mt FOREIGN KEY (parent_id) REFERENCES public.catalog_source(source_id);


--
-- Name: users_roles fk_datalayer_server; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_roles
    ADD CONSTRAINT fk_datalayer_server FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: users_clients fkkvrf67oq0dsiwmt3uylmh3efy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_clients
    ADD CONSTRAINT fkkvrf67oq0dsiwmt3uylmh3efy FOREIGN KEY (client_client_id) REFERENCES public.oauth_client_details(client_id);


--
-- Name: catalog_source fkqp49wbw30a0rc1al8lbax7pll; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog_source
    ADD CONSTRAINT fkqp49wbw30a0rc1al8lbax7pll FOREIGN KEY (topic_id) REFERENCES public.catalog_topics(topic_id);


--
-- Name: job cron_job_policy; Type: POLICY; Schema: cron; Owner: postgres
--

CREATE POLICY cron_job_policy ON cron.job USING ((username = (CURRENT_USER)::text));


--
-- Name: job; Type: ROW SECURITY; Schema: cron; Owner: postgres
--

ALTER TABLE cron.job ENABLE ROW LEVEL SECURITY;

--
-- Name: TABLE access_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.access_log TO replicator;


--
-- Name: TABLE catalog_source; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.catalog_source TO replicator;


--
-- Name: TABLE catalog_topics; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.catalog_topics TO replicator;


--
-- Name: TABLE clientdetails; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.clientdetails TO replicator;


--
-- Name: TABLE oauth_access_token; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.oauth_access_token TO replicator;


--
-- Name: TABLE oauth_approvals; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.oauth_approvals TO replicator;


--
-- Name: TABLE oauth_client_details; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.oauth_client_details TO replicator;


--
-- Name: TABLE oauth_client_token; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.oauth_client_token TO replicator;


--
-- Name: TABLE oauth_code; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.oauth_code TO replicator;


--
-- Name: TABLE oauth_refresh_token; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.oauth_refresh_token TO replicator;


--
-- Name: TABLE passwords; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.passwords TO replicator;


--
-- Name: TABLE temp_marinha; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.temp_marinha TO replicator;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.users TO replicator;


--
-- Name: TABLE users_clients; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.users_clients TO replicator;


--
-- Name: TABLE users_roles; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.users_roles TO replicator;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT ON TABLES  TO replicator;


--
-- PostgreSQL database dump complete
--

